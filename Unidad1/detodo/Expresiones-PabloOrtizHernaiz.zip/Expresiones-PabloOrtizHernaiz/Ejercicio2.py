#Ejercicio 2. Transforma los textos siguientes en código de Python:

#a) m es dividido entre 3 y almacenado en la variable p

m = int(input("escribe un valor "))

p = m/3

#b) m menos 6 almacenado en la variable q

q = m-6

#Prueba del ejercicio
print(p,q)
