#Ejercicios de Expresiones y operadores

#Ejercicio 1. Calcula las siguientes operaciones y muéstralas en pantalla:

#a) 3 + 6
print("Suma:",(3+6))
#b) 5 – 4
print("Resta:",(5-4))
#c) 6 * 3
print("Multiplicación:",(6*3))
#d) 8 / 2
print("División:",(8/2))
#e) 3 ^ 3
print("Potencia:",(3**3))
