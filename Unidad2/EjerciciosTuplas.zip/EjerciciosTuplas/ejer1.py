# Ejercicios Tuplas
# Ejercicio 1:
# A. Crea una tupla con los nombres de los días de la semana.
# B. Imprime el tercer día de la semana.
# C. Imprime los días de la semana en orden inverso.

dias_semana = ("lunes","martes","miércoles","jueves","viernes","sábado","domingo")

print(f"El tercer día de la semana es: {dias_semana[2]}")
print(f"El tercer día de la semana es: {dias_semana[::-1]}")

