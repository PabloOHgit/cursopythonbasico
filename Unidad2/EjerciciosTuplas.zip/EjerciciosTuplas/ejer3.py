# Ejercicio 3:
# A. Crea una tupla con los números del 1 al 10.
# B. Calcula la suma de todos los números.

numeros = (1,2,3,4,5,6,7,8,9,10)

suma = sum(numeros)

print(suma)
