# Ejercicio 4:
# A. Crea una tupla de tuplas para representar una matriz de 3x3.
# B. Imprime el elemento en la segunda fila y tercera columna.

tupla3x3 = ((1,2,3),(4,5,6),(7,8,9))

print(tupla3x3[1][2])
