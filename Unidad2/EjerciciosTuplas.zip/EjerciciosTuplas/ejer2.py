# Ejercicio 2:
# A. Crea una tupla con tus datos personales (nombre, apellido, edad).
# B. Imprime una frase que incluya tus datos.

datos_personales = ("Pablo", "Ortiz", 43)

print(f"Mis datos personales son los siguientes, nombre: {datos_personales[0]}, apellido: {datos_personales[1]} y mi edad: {datos_personales[2]}")