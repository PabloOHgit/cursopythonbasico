# Ejercicio 3. Crear un programa que cuente las palabras que tiene una oración.

frase = input("Introduce una frase para calcular cuántas palabras tiene: ")

print(f"La oración tiene {frase.count(" ")+1} palabras")