#Ejercicio 1: Crea un programa utilizando el bucle while en que hay que mostrar
#por pantalla números del 1 al 10. 

contador = 0
while(contador < 10):
    contador +=1
    print(contador)