#Ejercicio 1: Crea un programa utilizando el bucle for en que hay que mostrar
#por pantalla números del 1 al 10.

for i in range(1,11,1):
    print(i)