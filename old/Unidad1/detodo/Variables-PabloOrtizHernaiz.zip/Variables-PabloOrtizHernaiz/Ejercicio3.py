"""Ejercicio 3. Escriba un programa que solicite al usuario tres letras y los muestre
al revés."""

primeraLetra = input("Introduce primer valor")
segundaLetra = input("Introduce segundo valor")
terceraLetra = input("Introduce tercer valor")

mostrarLetras = (terceraLetra,segundaLetra,primeraLetra)

print(mostrarLetras)