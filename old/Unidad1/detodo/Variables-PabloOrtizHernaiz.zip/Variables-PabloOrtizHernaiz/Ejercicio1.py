#Ejercicio 1.
"""a) Crea un variable llamada perros y asígnale el valor que el usuario
introduzca por teclado."""

perros = input("Introduce un nombre de perro:")

#b) Crea una variable llamada comida y asígnale el valor 200.

comida = 200

#c) Muestra el contenido de la variable perros.

print("El nombre elegido para el perro es: " +perros)

#d) Modifica el valor de la variable perros a 150.

perros = 150

#e) Copia el valor de la variable perros en la variable comida.

comida = perros

#f) Imprime el valor de las dos variables con print(). 

print("El valor de la variable perros es: ",perros)
print("El valor de la variable comida es: ",comida)