#Ejercicio 2.
#a) Escribe la palabra elefante dentro de una variable llamada animal.

animal = ("elefante")

#b) Escribe la palabra rosa dentro de una variable llamada color.

color = ("rosa")

"""c) Crea una variable llamada imagina donde se almacenen las dos variables
anteriores: animal y color dando como resultado el valor elefanterosa."""

imagina = (animal+color)

"""d) En la variable imagina intercala un espacio en blanco para separar las dos
palabras."""

imagina = (animal+" "+color)

#Prueba del ejercicio
print(imagina)