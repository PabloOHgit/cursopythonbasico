"""Ejercicio 4. Crea un programa que pregunte al usuario: ¿Cómo te llamas? y
guarde el nombre en la variable x. El programa debe responder: Encantado de
conocerte, x"""

x = input("¿Cómo te llamas? ")

print("Encantado de conocerte:",x)